
# coding: utf-8

# In[106]:

get_ipython().magic('run SketchFunctions.py')


# ---
# 
# # Setting up for Simulation

# ### Simulation Parameters
# 
# * `N`: observations
# * `D`: parameters
# * `gamma`: sketch Compression Level
# * `link`: GLM Link function, currently supports 'linear' and 'logistic'
# * `beta_true`: Randomly generate true coefficients
# * `dataX, dataY`: randomly generated data for regression modeling
# * `beta_hat`: Estimate from full GLM fit

# In[2]:

N = 2**10
D = 100
gamma = 4
link = "linear"
beta_true = np.random.uniform(-2, 2, D).reshape(D, 1)
dataX, dataY = generateData(N, beta_true, link=link, sigma=1.0)
beta_hat = lm(dataX, dataY)


# ### TensorFlow Placeholders

# In[3]:

# placeholding tensors and variable
X = tf.placeholder('float', [None, D]) 
Y = tf.placeholder('float', [None, 1])
beta = tf.Variable(tf.random_normal([D, 1], stddev=1.0))


# In[4]:

if link == 'linear':
    # linear regression with mean squared error
    Y_hat = tf.matmul(X, beta)
    loss = tf.reduce_sum(tf.square(Y - Y_hat))
elif link == 'logistic':
    # logistic regression with log loss
    eta = tf.matmul(X, beta)
    p = 1.0 / (1.0 + tf.exp(-eta))
    loss = -1.0 * (tf.reduce_sum(Y * tf.log(p) + (1.0 - Y) * tf.log(1 - p)))    


# ### TensorFlow Loss, Grad, Hess

# In[31]:

# Gradient of loss function
grad = tf.gradients(loss, beta)


# In[34]:

# Hessian and Fisher Information
hessian = compute_hessian(beta, grad)
fisher = tf.matrix_inverse(hessian)


# In[35]:

# TensorFlow code to Update beta by delta
delta = tf.placeholder('float', [D, 1])
update = beta.assign_add(delta)


# ### Set up Stopping Criteria, Note-taking Variables

# In[36]:

# Simulation Parameters
MAXITER = 50
TOL = 10**(-12)

# For Recording Sample Path
path = np.zeros((MAXITER, D + 1))


# 
# ---
# 
# # Example Simulation
# 
# ##### The following cell gives an example of running a Iterated Hessian Sketch simulation.
# 
# ##### Here are a few notes on the implementation of IHS given here.  Fuller details are discussed in the accompanying write-up.
# 
# - At each iteration of the Newton-Raphson algorithm, a random projection is applied to the sample data.  The gradient and Hessian are then computed on this sketched data and the coefficient vector estimate is updated following the usual Newton-Raphson procedure.<br><br>
# 
# - A crude half-stepping procedure is used here to help ensure that the loss function is decreasing steadily.<br><br>
#     
# * The `stepsize` is reset to 1 at each iteration to encourage larger steps (relative to the grad-FisherInfo).  More intelligent step-sizing can likely be used to increase convergence in practical settings.<br><br>
#     
# * The algorithm will run for the fixed number of iterations given by `MAXITER`, but convergence to an acceptable tolerance may occur sooner.  Theoretical results (Pilanci 2015) give formulas to calculate or approximate the needed number of iterations to achieve a desired error tolerance. <br><br>
#     
# * This code fits the regression model with the Newton-Raphson method, applying a sketching matrix to _both_ the gradient and the Hessian.<br><br>
# 
# * __N.B.__ This actually differs from the method given in the Pilanci & Wainwright 2015 description, where the sketching is applied only to the Hessian matrix.  While their derived theoretical bounds apply specifically to the case of sketching only on the Hessian, we have found that sketching on the gradient actually seems to improve performance in this simple setting.  It is not clear if sketching on the gradient as well will maintain accuracy and computational gains in more complicated settings.<br><br>
# 
# ##### Important Simulation settings used are:
# 
# * Gaussian sketching
# * `N = 1024`
# * `D = 100`
# * `gamma = 4` compression, for sketch dimension of `R = gamma * D = 400`
# * `MAXITER = 50`
# * `X` ~ Normal(0, 1) [i.i.d.]
# * `Y` data generated from Normal OLS model with linear link [i.i.d.]
# * True beta coefficients ~ Uniform(-2, 2) [i.i.d.]
# * Initial beta estimates drawn from random Normal(0, 1)

# In[37]:

with tf.Session() as sess:
    tf.global_variables_initializer().run()
    stepsize = 1.0
    for i in range(MAXITER):          
        # Sketching with chosen method and compression factor
        sketchX, sketchY = sketch(dataX, dataY, gamma, method='gaussian')
        
        # Compute Gradient
        g = sess.run(grad, feed_dict={X: sketchX, Y: sketchY})[0]
        
        # Compute Fisher Info
        I = sess.run(fisher, feed_dict={X: sketchX, Y: sketchY})
        
        # Take Newton-Raphson Step
        stepsize = 1.0
        current_loss = sess.run(loss, feed_dict={X: dataX, Y: dataY})
        sess.run(update, feed_dict={delta : -np.dot(I, g) * stepsize})
        new_loss = sess.run(loss, feed_dict={X: dataX, Y: dataY})
        
        # Backstepping to ensure decrease in loss function
        while (new_loss > current_loss) and (stepsize > TOL):
            stepsize = stepsize / 2.0
            sess.run(update, feed_dict={delta : np.dot(I, g) * stepsize})
            new_loss = sess.run(loss, feed_dict={X: dataX, Y: dataY})
        stepsize = min(1.0, 2 * stepsize)
        
        # Note step and new error ratio
        path[i, :-1] = np.transpose(beta.eval())
        path[i, -1] = get_ratio(path[i, :-1], beta_true)


# ---
# 
# # Run Simulations
# 
# ###### The `simulate()` function below is a wrapper for the entire simulation process outlined above.  Full code and supporting documentation are provided in the SketchFunctions.py file.
# 
# ###### The following cell runs the simulation and provides the error output.  The path of optimization path of beta parameters and error ratios are returned by the function later use.
# 
# ### Common Settings for All Simulations
# 
# * `MAXITER = 50`
# * `X` ~ Normal(0, $\sigma$) [i.i.d.]
# * `Y` data generated from Normal OLS model with linear link [i.i.d.]
# * True beta coefficients ~ Uniform(-2, 2) [i.i.d.]
# * Initial beta estimates drawn from random Normal(0, 1)

# ---
# 
# ## Simulation 1A

# In[115]:

get_ipython().magic('run SketchFunctions.py')
N = 2**10
D = 2**7
sigma = 1.0
gamma = 4
sim_id = '1A'

method = 'gaussian'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'hadamard'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'sampling'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)


# ---
# 
# ## Simulation 1B

# In[126]:

N = 2**10
D = 2**7
sigma = 1.0
gamma = 6
sim_id = '1B'

method = 'gaussian'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'hadamard'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'sampling'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)


# ---
# 
# ## Simulation 1C

# In[97]:

N = 2**10
D = 2**7
sigma = 1.0
gamma = 8
sim_id = '1C'

method = 'gaussian'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'hadamard'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'sampling'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)


# ---
# 
# ## Simulation 2A

# In[120]:

N = 2**10
D = 2**7
sigma = 12.0
gamma = 2
sim_id = '2A'

method = 'gaussian'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'hadamard'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'sampling'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)


# ---
# 
# ## Simulation 2B

# In[121]:

N = 2**10
D = 2**7
sigma = 12.0
gamma = 4
sim_id = '2B'

method = 'gaussian'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'hadamard'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'sampling'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)


# ---
# 
# ## Simulation 2C

# In[123]:

N = 2**10
D = 2**7
sigma = 12.0
gamma = 6
sim_id = '2C'

method = 'gaussian'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'hadamard'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'sampling'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)


# ---
# 
# ## Simulation 2D

# In[124]:

N = 2**10
D = 2**7
sigma = 12.0
gamma = 8
sim_id = '2D'

method = 'gaussian'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'hadamard'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'sampling'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)


# ---
# 
# ## Simulation 3A

# In[125]:

N = 2**12
D = 2**9
sigma = 50.0
gamma = 4
sim_id = '3A'

method = 'gaussian'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'hadamard'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'sampling'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)


# ---
# 
# ## Simulation 3B

# In[127]:

N = 2**12
D = 2**9
sigma = 50.0
gamma = 6
sim_id = '3B'

method = 'gaussian'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'hadamard'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'sampling'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)


# ---
# 
# ## Simulation 3C

# In[ ]:

N = 2**12
D = 2**9
sigma = 50.0
gamma = 8
sim_id = '3C'

method = 'hadamard'
path_out = 'sim{0}_{1}.csv'.format(sim_id, method)
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)


# ---
# ## Simulation 4

# In[98]:

N = 2**14
D = 2**7
sigma = 1.0
gamma = 6
method = 'gaussian'
path_out = 'sim1A_gaussian.csv'
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'hadamard'
path_out = 'sim1A_hadamard.csv'
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

method = 'sampling'
path_out = 'sim1A_sampling.csv'
path = simulate(N = N, D = D, sigma = sigma, 
                gamma = gamma, MAXITER = 50, method = method,  path_out = path_out)

